# T1GER MECHANIC JOB

### Requirements
- progressBars [https://github.com/Hamza8700/fivem_scripts/tree/master/progressBars]

### Installation
1) Drag & drop the t1ger_mechanicjob into your `resources` server folder.
2) Configure the config file to your liking.
3) Install the required requirements and add to server config.
4) Run the provided .sql file and make sure everything is added to the database.
5) Add `start t1ger_mechanicjob` to your server config.
6) Make sure to read through the README!!!!

### Showcase
- 

